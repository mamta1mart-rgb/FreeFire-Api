import { generateJWEAndJWS } from 'payglocal-js-client';
import crypto from 'crypto';

// Products mapping from website catalog based on checkout price
const WEBSITE_PRODUCT_CATALOG = {
  '395.50': [
    'Wide Leg Fit Jeans With 4 Pocket For Women',
    'Wall Mounted Bathroom Storage Shelf with Towel Rack'
  ],
  '450': [
    'Race Print T-Shirt & Shorts Set For Boys'
  ],
  '490': [
    'Wide Leg Fit Jeans With 5 Pocket For Women',
    'Korean Fashion Oversized Casual Cotton T-Shirt'
  ],
  '499': [
    'Women Multi Coloured Floral Regular Fit Crop Top',
    'Light Blue Mid Embroidered Rise Fit Skirt For Women',
    'Wide Leg Fit Jeans With 6 Pocket For Women'
  ],
  '550': [
    'Women Multi Coloured Floral Regular Fit Crop Top',
    'Black High Rise Skinny Fit Shapewear For Women',
    'Drop Shoulder Sleeves Regular Fit Sweatshirt For Women',
    'Portable Handheld Ring LED Light Photography Lamp'
  ],
  '750': [
    'Blue Stripes Relaxed Fit Shirt For Women',
    'Nylon Blend Regular Fit Bra For Women',
    'Solid Tube Bra For Women',
    'Mens Corduroy Loose Fit Wide Leg Pants'
  ],
  '1000': [
    'Floral Print Straight Kurta For Women',
    'Yellow Puff Sleeves Regular Fit Dress For Women',
    'Men Slim Fit Denim Jacket Vintage Edition'
  ],
  '1100': [
    'White and Black Wide Leg Fit Casual Trouser With 2 Pocket For Women',
    'Regular Fit Casual Trouser With 1 Pocket For Women',
    'Light Blue Solid Flared Jeans For Women',
    'BT21 Anime Cartoon Keychain Doll Pendant'
  ],
  '1400': [
    'Stripes Regular Fit Shirt For Men',
    'Skinny Fit Jeans With 5 Pocket For Women',
    'Striped Regular Fit T-Shirt For Infant Boys',
    'Cute Bear Phone Charms & Keychain Pendant'
  ],
  '5500': [
    'Slim Fit Utility Pocket Trouser For Men',
    'Mens Slim Solid Navy Formal Trousers',
    'Solid Rayon Pant For Women',
    'LED Selfie Ring Lamp with Phone Holder & Tripod',
    'Cotton Blend Straight Fit Trouser for Women'
  ],
  '7500': [
    'Olive Slim Fit Utility Pocket Trouser For Men',
    'Cotton Blend Regular Fit Shirt For Men',
    'Cotton Blend Solid Pant For Women',
    'Solid Plazzos For Women And Girls',
    'Stylish Women Maroon Gown Dress'
  ]
};

function getRandomProductForPrice(price) {
  const priceKey = String(price).trim();
  const list = WEBSITE_PRODUCT_CATALOG[priceKey];
  if (list && list.length > 0) {
    const idx = Math.floor(Math.random() * list.length);
    return list[idx];
  }
  return 'Women Multi Coloured Floral Regular Fit Crop Top';
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method Not Allowed' });
  
  try {
    const { amount, customerData, source } = req.body;
    
    if (!amount || !customerData) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const merchantTxnId = `PG-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const host = req.headers.host || 'localhost:3000';
    const protocol = req.headers['x-forwarded-proto'] || (host.includes('localhost') ? 'http' : 'https');
    
    // Pick a random matching legitimate website product purely on backend
    const resolvedProductName = getRandomProductForPrice(amount);
    const formattedAmount = Number(amount).toFixed(2).toString();

    const isGarena = source === 'garena';
    const callbackSourceParam = isGarena ? '&src=garena' : '';

    // Format phone: ensure 10 digits without leading 91 or +91 for phoneNumber field
    let rawPhone = String(customerData.phone || '9999999999').replace(/[^0-9]/g, '');
    if (rawPhone.length > 10 && (rawPhone.startsWith('91') || rawPhone.startsWith('+91'))) {
      rawPhone = rawPhone.slice(-10);
    }
    const cleanPhone = rawPhone.slice(-10).padStart(10, '9');

    // For Garena Checkout: Send only country 'IN' (no street/city/state/pincode)
    // For Website Checkout: Send full customer shipping address
    const billingInfo = isGarena ? {
      firstName: customerData.firstName || "Customer",
      lastName: customerData.lastName || "",
      emailId: customerData.email || "customer@gmail.com",
      callingCode: "+91",
      phoneNumber: cleanPhone,
      addressCountry: "IN"
    } : {
      firstName: customerData.firstName || "Customer",
      lastName: customerData.lastName || "",
      emailId: customerData.email || "customer@gmail.com",
      callingCode: "+91",
      phoneNumber: cleanPhone,
      addressCountry: "IN",
      addressStreet1: customerData.address || "Main Street",
      addressCity: customerData.city || "Delhi",
      addressState: customerData.state || "Delhi",
      addressPostalCode: customerData.pincode || "110001"
    };

    const payload = {
      merchantTxnId,
      comments: resolvedProductName,
      paymentData: {
        totalAmount: formattedAmount,
        txnCurrency: "INR",
        comments: resolvedProductName,
        billingData: billingInfo
      },
      billingData: billingInfo,
      riskData: {
        orderItems: [
          {
            itemId: `SKU-${Math.round(amount)}`,
            itemName: resolvedProductName,
            itemDescription: resolvedProductName,
            itemCategory: "APPAREL_AND_ACCESSORIES",
            itemQuantity: 1,
            itemPrice: formattedAmount
          }
        ]
      },
      merchantCallbackURL: `${protocol}://${host}/api/payglocal/callback?txnId=${merchantTxnId}${callbackSourceParam}`
    };

    console.log(`[Backend Gateway Init] TxnId: ${merchantTxnId}, Amount: ₹${formattedAmount}, Product: "${resolvedProductName}"`);


    function loadKey(raw) {
      if (!raw) throw new Error('KEY ENV EMPTY');
      let k = raw.trim();
      if (!k.includes('-----BEGIN')) {              // stored as base64
        k = Buffer.from(k, 'base64').toString('utf8').trim();
      }
      k = k.replace(/\\n/g, '\n');                   // fix escaped newlines
      return k;
    }

    let privateKey = loadKey(process.env.PAYGLOCAL_PRIVATE_KEY);
    const publicKey = loadKey(process.env.PAYGLOCAL_PUBLIC_KEY);

    console.log('PRIV_DEBUG len=', privateKey.length,
                '| firstLine=', JSON.stringify(privateKey.split('\n')[0]),
                '| lines=', privateKey.split('\n').length,
                '| pkcs8=', privateKey.includes('BEGIN PRIVATE KEY'),
                '| pkcs1=', privateKey.includes('BEGIN RSA PRIVATE KEY'));

    // If key is PKCS#1, convert to PKCS#8 (jose needs PKCS#8)
    if (privateKey.includes('BEGIN RSA PRIVATE KEY')) {
      privateKey = crypto.createPrivateKey(privateKey)
                         .export({ type: 'pkcs8', format: 'pem' });
    }

    const { jweToken, jwsToken } = await generateJWEAndJWS({
      payload,
      publicKey,
      privateKey,
      merchantId: process.env.PAYGLOCAL_MERCHANT_ID,
      privateKeyId: process.env.PAYGLOCAL_PRIVATE_KEY_ID,
      publicKeyId: process.env.PAYGLOCAL_PUBLIC_KEY_ID
    });

    const initRes = await fetch("https://api.payglocal.in/gl/v1/payments/initiate/paycollect", {
      method: "POST",
      headers: {
        "Content-Type": process.env.PAYGLOCAL_CONTENT_TYPE || "application/json",
        "x-gl-token-external": jwsToken,
        "x-gl-merchantid": process.env.PAYGLOCAL_MERCHANT_ID,
        "x-gl-kid": process.env.PAYGLOCAL_PRIVATE_KEY_ID
      },
      body: jweToken
    });

    if (!initRes.ok) {
      const errTxt = await initRes.text();
      console.error("PayGlocal Init Error:", errTxt);
      return res.status(initRes.status).json({ error: 'Payment gateway error', details: errTxt });
    }

    const data = await initRes.json();
    console.log("=== FULL PAYGLOCAL INITIATE RESPONSE ===", JSON.stringify(data, null, 2));

    const gid = data.gid;
    const redirectUrl = data.data?.redirectUrl;

    console.log("=== PAYGLOCAL EXACT REDIRECT URL ===", redirectUrl);

    if (!gid || !redirectUrl) {
      return res.status(500).json({ error: 'Invalid response from PayGlocal', data });
    }

    return res.json({ redirectUrl, gid, merchantTxnId });

  } catch (error) {
    console.error("Initiate error:", error);
    return res.status(500).json({ error: error.message });
  }
}
