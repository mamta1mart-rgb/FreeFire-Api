import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Footer() {
  const navigate = useNavigate();
  const { user } = useAuth();

  return (
    <footer>
      <div className="footer-top">
        <div>
          <Link className="wordmark" to="/">
            FREE FIRE<span>STORE</span>
          </Link>
          <p>
            Premium Fashion & Apparel.
            <br />Your trusted destination for quality clothing across India.
          </p>
        </div>
        <div>
          <h4>Explore</h4>
          <Link to="/collections/women">Women</Link>
          <Link to="/collections/men">Men</Link>
          <Link to="/collections/kids">Kids</Link>
          <Link to="/collections/all">All pieces</Link>
        </div>
        <div>
          <h4>We're here to help</h4>
          <Link to="/contact">Contact us</Link>
          <Link to="/policies/shipping">Shipping & delivery</Link>
          <Link to="/policies/refund">Returns & exchanges</Link>
          <Link to={user ? "/my-orders" : "/login"}>My orders</Link>
        </div>
        <div>
          <h4>The finer details</h4>
          <Link to="/about">Our story</Link>
          <Link to="/policies/privacy">Privacy policy</Link>
          <Link to="/policies/terms">Terms of service</Link>
        </div>
      </div>
      <div className="footer-contact">
        <strong>
          Free Fire Store · Proprietor: KALPANA SINGH
        </strong>
        <p>PRANNATHPUR BACHHARIYA, SULTANPUR, UTTAR PRADESH, INDIA, 228171</p>
        <a href="mailto:connectwithgarena@gmail.com">connectwithgarena@gmail.com</a>
        <a href="tel:+917393845435">+91-7393845435</a>
        <span>Udyam Reg. No: UDYAM-UP-03-0123799</span>
      </div>
      <div className="footer-bottom">
        <span>© {new Date().getFullYear()} Free Fire Store. All rights reserved.</span>
        <span>Premium Fashion & Apparel</span>
        <span>INDIA · INR ₹</span>
      </div>
    </footer>
  );
}
