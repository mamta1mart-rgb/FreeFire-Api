import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { toast } from 'sonner';
import { Search, ShoppingBag, Menu, X, UserRound, Heart } from 'lucide-react';

export default function Navbar() {
  const { cart, removeFromCart, updateQty, getTotalPrice, cartCount, isCartOpen, setIsCartOpen } = useCart();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);
  const [searchText, setSearchQuery] = useState('');

  const handleSearchSubmit = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && searchText.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchText.trim())}`);
      setMobileDrawerOpen(false);
    }
  };

  useEffect(() => {
    setMobileDrawerOpen(false);
  }, [location]);

  const fmt = (n: number) => '₹' + n.toLocaleString('en-IN');
  const emoji = (cat: string) => cat === 'men' ? '👕' : cat === 'women' ? '👗' : '💻';

  return (
    <>
      <div className="announcement">
        FREE FIRE STORE — PREMIUM FASHION & APPAREL{" "}
        <span>
          Discover the new edit <Search size={12} />
        </span>
      </div>

      <header>
        <Link className="wordmark" to="/">
          FREE FIRE<span>STORE</span>
        </Link>
        <nav className={mobileDrawerOpen ? "open" : ""}>
          <Link to="/collections/all">Shop all</Link>
          <Link to="/collections/women">Women</Link>
          <Link to="/collections/men">Men</Link>
          <Link to="/collections/kids">Kids</Link>
        </nav>
        <div className="header-actions">
          <Link to={user ? "/my-orders" : "/login"} aria-label="My account">
            <UserRound size={20} />
          </Link>
          <Link to="/search" aria-label="Search">
            <Search size={20} />
          </Link>
          <Link to="/wishlist" aria-label="Wishlist">
            <Heart size={20} />
          </Link>
          <button
            className="bag-link"
            aria-label={`Shopping bag, ${cart.reduce((n, x) => n + x.qty, 0)} items`}
            onClick={() => setIsCartOpen(true)}
          >
            <ShoppingBag size={20} />
            <span>{cart.reduce((n, x) => n + x.qty, 0)}</span>
          </button>
          <button
            className="menu-toggle"
            aria-label={mobileDrawerOpen ? "Close menu" : "Open menu"}
            onClick={() => setMobileDrawerOpen(!mobileDrawerOpen)}
          >
            {mobileDrawerOpen ? <X /> : <Menu />}
          </button>
        </div>
      </header>

      <div
        className={`mob-overlay ${mobileDrawerOpen ? 'open' : ''}`}
        onClick={() => setMobileDrawerOpen(false)}
      />

      <div className={`mob-drawer ${mobileDrawerOpen ? 'open' : ''}`}>
        <button className="drawer-close" onClick={() => setMobileDrawerOpen(false)}>
          <X />
        </button>
        <div className="drawer-logo">FREE FIRE STORE</div>

        {user && (
          <div style={{ background: '#f8fafc', padding: '12px 16px', border: '1px solid var(--border)', margin: '12px 0 16px' }}>
            <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--dark)' }}>👤 {user.name || 'User'}</div>
            <div style={{ fontSize: '11px', color: 'var(--gray)', wordBreak: 'break-all' }}>📧 {user.email}</div>
            {user.mobile && <div style={{ fontSize: '11px', color: 'var(--gray)' }}>📱 {user.mobile}</div>}
          </div>
        )}

        <div className="mob-search">
          <Search size={16} style={{ color: '#aaa', flexShrink: 0 }} />
          <input
            type="text"
            placeholder="Search products..."
            value={searchText}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={handleSearchSubmit}
          />
        </div>
        <div className="drawer-nav">
          <Link to="/" onClick={() => setMobileDrawerOpen(false)}>Home</Link>
          <Link to="/collections/all" onClick={() => setMobileDrawerOpen(false)}>Shop All</Link>
          <Link to="/collections/women" onClick={() => setMobileDrawerOpen(false)}>Women</Link>
          <Link to="/collections/men" onClick={() => setMobileDrawerOpen(false)}>Men</Link>
          <Link to="/collections/kids" onClick={() => setMobileDrawerOpen(false)}>Kids</Link>
          <Link to={user ? "/my-orders" : "/login"} onClick={() => setMobileDrawerOpen(false)}>
            {user ? 'My Profile & Orders' : 'Login / Register'}
          </Link>
          <Link to="/policies/shipping" onClick={() => setMobileDrawerOpen(false)}>Shipping</Link>
          <Link to="/contact" onClick={() => setMobileDrawerOpen(false)}>Contact</Link>

          {user && (
            <button
              onClick={() => {
                logout();
                setMobileDrawerOpen(false);
                toast.success('Logged out successfully.');
                navigate('/login');
              }}
              style={{
                width: '100%',
                padding: '12px',
                background: 'var(--red)',
                color: '#ffffff',
                border: 'none',
                fontFamily: 'var(--font-h)',
                fontWeight: 700,
                fontSize: '11px',
                letterSpacing: '1.5px',
                marginTop: '20px',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px'
              }}
            >
              <X size={16} /> LOG OUT
            </button>
          )}
        </div>
      </div>

      <div
        className={`cart-overlay ${isCartOpen ? 'open' : ''}`}
        onClick={() => setIsCartOpen(false)}
      />

      <div className={`cart-drawer ${isCartOpen ? 'open' : ''}`}>
        <div className="cart-head">
          <h3>YOUR BAG ({cartCount})</h3>
          <button className="cart-close" onClick={() => setIsCartOpen(false)}>
            <X />
          </button>
        </div>
        <div className="cart-items">
          {cart.length === 0 ? (
            <div className="cart-empty">
              <ShoppingBag size={48} style={{ color: 'var(--light)' }} />
              <p>Your bag is empty</p>
              <button
                className="btn btn-black btn-full"
                onClick={() => { setIsCartOpen(false); navigate('/collections/all'); }}
              >
                START SHOPPING
              </button>
            </div>
          ) : (
            cart.map((item) => (
              <div className="cart-item" key={item.key}>
                <Link to={`/product/${item.id}`} onClick={() => setIsCartOpen(false)} style={{ display: 'block', flexShrink: 0 }}>
                  {item.image ? (
                    <img
                      src={item.image}
                      alt={item.name}
                      className="cart-item-img"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className={`ph ph-${item.cat === 'electronics' ? 'elec' : item.cat} cart-item-img`} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '28px' }}>
                      {emoji(item.cat)}
                    </div>
                  )}
                </Link>
                <div className="ci-info">
                  <Link to={`/product/${item.id}`} onClick={() => setIsCartOpen(false)} style={{ textDecoration: 'none', color: 'inherit' }}>
                    <div className="ci-name" style={{ cursor: 'pointer' }}>{item.name}</div>
                  </Link>
                  <div className="ci-size">Size: {item.size}</div>
                  <div className="ci-qty">
                    <button onClick={() => updateQty(item.key, -1)}>−</button>
                    <span>{item.qty}</span>
                    <button onClick={() => updateQty(item.key, 1)}>+</button>
                  </div>
                  <div className="ci-price">{fmt(item.price * item.qty)}</div>
                </div>
                <button className="ci-remove" onClick={() => removeFromCart(item.key)}>
                  <X size={16} />
                </button>
              </div>
            ))
          )}
        </div>

        {cart.length > 0 && (
          <div className="cart-foot">
            <div className="cart-total-row">
              <span className="cart-total-label">SUBTOTAL</span>
              <span className="cart-total-price">{fmt(getTotalPrice())}</span>
            </div>
            <div style={{ background: 'var(--bg)', border: '1px solid var(--border)', padding: '10px 14px', fontSize: '13px', color: 'var(--dark)', fontFamily: 'var(--font-h)', fontWeight: 700, marginBottom: '16px' }}>
              ✓ FREE SHIPPING ON THIS ORDER
            </div>
            <button
              className="btn btn-black btn-full btn-lg"
              onClick={() => { setIsCartOpen(false); navigate('/cart'); }}
            >
              VIEW BAG & CHECKOUT
            </button>
          </div>
        )}
      </div>
    </>
  );
}
