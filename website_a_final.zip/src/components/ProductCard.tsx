import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../data/products';
import { Heart, ArrowUpRight } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

const money = (n: number) => '₹' + n.toLocaleString('en-IN');

export default function ProductCard({ product }: ProductCardProps) {
  const [hovered, setHovered] = useState(false);
  const [imgError, setImgError] = useState(false);

  const colorCount = product.colors ? product.colors.length : (product.variants ? new Set(product.variants.map(v => v.color).filter(Boolean)).size : 0);
  const catLabel = product.cat === 'women' ? 'THE WOMENSWEAR EDIT' : product.cat === 'men' ? 'THE MENSWEAR EDIT' : 'THE EVERYDAY EDIT';

  return (
    <article className="product-card">
      <div
        className="product-photo"
        onMouseEnter={() => {
          if (matchMedia('(hover: hover)').matches) setHovered(true);
        }}
        onMouseLeave={() => setHovered(false)}
      >
        <Link to={`/product/${product.id}`}>
          <img
            loading="lazy"
            src={!imgError && product.images && product.images[0] ? product.images[0] : '/placeholder.svg'}
            alt={product.name}
            onError={() => setImgError(true)}
          />
          {hovered && product.images && product.images[1] && (
            <img
              className="hover-image"
              loading="lazy"
              src={product.images[1]}
              alt="Alternate view"
              onError={() => {}}
            />
          )}
        </Link>
        {product.badge === 'NEW' && <span className="product-label">NEW IN</span>}
        <button className="save" aria-label={`Save ${product.name}`}>
          <Heart size={17} />
        </button>
        <Link className="discover" to={`/product/${product.id}`}>
          Discover this piece <ArrowUpRight size={16} />
        </Link>
      </div>
      <div className="card-meta">
        <span>{catLabel}</span>
        {colorCount > 1 && <span>{colorCount} colours</span>}
      </div>
      <Link className="product-name" to={`/product/${product.id}`}>
        {product.name}
      </Link>
      <div className="price">{money(product.price)}</div>
    </article>
  );
}
