import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useProducts } from '../context/ProductContext';
import { Search, ArrowUpRight } from 'lucide-react';
import ProductCard from '../components/ProductCard';

const money = (n: number) => '₹' + n.toLocaleString('en-IN');

export default function Collection() {
  const { category = 'all' } = useParams<{ category?: string }>();
  const navigate = useNavigate();
  const { products } = useProducts();

  const [selectedCats, setSelectedCats] = useState<Record<string, boolean>>({
    men: category === 'men' || category === 'all',
    women: category === 'women' || category === 'all',
    kids: category === 'kids' || category === 'all',
  });

  const [priceRange, setPriceRange] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('featured');

  useEffect(() => {
    const catName = category.toUpperCase();
    document.title = `${catName} Collection – Free Fire Store`;

    setSelectedCats({
      men: category === 'men' || category === 'all',
      women: category === 'women' || category === 'all',
      kids: category === 'kids' || category === 'all',
    });
  }, [category]);

  const handleCatCheckboxChange = (cat: string) => {
    setSelectedCats(prev => ({
      ...prev,
      [cat]: !prev[cat],
    }));
  };

  const filteredProducts = products.filter(p => {
    const isCatSelected = selectedCats[p.cat];
    if (!isCatSelected) return false;

    if (priceRange === 'under500' && p.price >= 500) return false;
    if (priceRange === '500-1000' && (p.price < 500 || p.price > 1000)) return false;
    if (priceRange === '1000-2000' && (p.price < 1000 || p.price > 2000)) return false;
    if (priceRange === 'above2000' && p.price <= 2000) return false;

    return true;
  }).sort((a, b) => {
    if (sortBy === 'low') return a.price - b.price;
    if (sortBy === 'high') return b.price - a.price;
    if (sortBy === 'new') {
      if (a.badge === 'NEW' && b.badge !== 'NEW') return -1;
      if (a.badge !== 'NEW' && b.badge === 'NEW') return 1;
    }
    return 0;
  });

  const pageTitle = category === 'all'
    ? 'All Products'
    : category === 'men'
      ? "Men's Collection"
      : category === 'women'
        ? "Women's Collection"
        : category === 'kids'
          ? "Kids' Collection"
          : 'Apparel Collection';

  const productCountText = `${filteredProducts.length} ${filteredProducts.length === 1 ? 'product' : 'products'}`;

  return (
    <>
      <nav className="breadcrumb">
        <div className="container">
          <div className="breadcrumb-inner">
            <Link to="/">Home</Link>
            <span className="sep">/</span>
            <span className="curr">{pageTitle}</span>
          </div>
        </div>
      </nav>

      <div className="page-hero">
        <div className="container">
          <h1>{pageTitle}</h1>
          <p>{productCountText} available</p>
        </div>
      </div>

      <div className="container">
        <div className="shop-layout">
          <aside className="filters-panel">
            <h3>FILTERS</h3>
            <div className="filter-group">
              <h4>CATEGORY</h4>
              <div className="filter-option">
                <input
                  type="checkbox"
                  id="f-men"
                  checked={selectedCats.men}
                  onChange={() => handleCatCheckboxChange('men')}
                />
                <label htmlFor="f-men">Men ({products.filter(p => p.cat === 'men').length})</label>
              </div>
              <div className="filter-option">
                <input
                  type="checkbox"
                  id="f-women"
                  checked={selectedCats.women}
                  onChange={() => handleCatCheckboxChange('women')}
                />
                <label htmlFor="f-women">Women ({products.filter(p => p.cat === 'women').length})</label>
               </div>
             </div>

             <div className="filter-group">
               <h4>PRICE</h4>
              <div className="filter-option">
                <input
                  type="radio"
                  name="price"
                  id="pr-all"
                  checked={priceRange === 'all'}
                  onChange={() => setPriceRange('all')}
                />
                <label htmlFor="pr-all">All prices</label>
              </div>
              <div className="filter-option">
                <input
                  type="radio"
                  name="price"
                  id="pr-1"
                  checked={priceRange === 'under500'}
                  onChange={() => setPriceRange('under500')}
                />
                <label htmlFor="pr-1">Under ₹500</label>
              </div>
              <div className="filter-option">
                <input
                  type="radio"
                  name="price"
                  id="pr-2"
                  checked={priceRange === '500-1000'}
                  onChange={() => setPriceRange('500-1000')}
                />
                <label htmlFor="pr-2">₹500 – ₹1,000</label>
              </div>
              <div className="filter-option">
                <input
                  type="radio"
                  name="price"
                  id="pr-3"
                  checked={priceRange === '1000-2000'}
                  onChange={() => setPriceRange('1000-2000')}
                />
                <label htmlFor="pr-3">₹1,000 – ₹2,000</label>
              </div>
              <div className="filter-option">
                <input
                  type="radio"
                  name="price"
                  id="pr-4"
                  checked={priceRange === 'above2000'}
                  onChange={() => setPriceRange('above2000')}
                />
                <label htmlFor="pr-4">Above ₹2,000</label>
              </div>
            </div>
          </aside>

          <div>
            <div className="shop-toolbar">
              <span className="shop-count">{productCountText}</span>
              <select
                className="sort-select"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
              >
                <option value="featured">FEATURED</option>
                <option value="low">PRICE: LOW TO HIGH</option>
                <option value="high">PRICE: HIGH TO LOW</option>
                <option value="new">NEW ARRIVALS</option>
              </select>
            </div>

            {filteredProducts.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '60px 20px' }}>
                <div style={{ fontSize: '48px', marginBottom: '16px' }}>🔍</div>
                <h2 style={{ fontSize: '1.2rem', textTransform: 'uppercase', letterSpacing: '2px', marginBottom: '8px' }}>NO PRODUCTS FOUND</h2>
                <p style={{ color: 'var(--gray)' }}>Try adjusting your filters or browse another category.</p>
              </div>
            ) : (
              <div className="product-grid" id="shopAllGrid">
                {filteredProducts.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
