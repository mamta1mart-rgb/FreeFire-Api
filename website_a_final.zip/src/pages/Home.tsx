import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useProducts } from '../context/ProductContext';
import { ArrowUpRight, ArrowRight, Truck, ShoppingBag, UserRound } from 'lucide-react';
import ProductCard from '../components/ProductCard';

const money = (n: number) => '₹' + n.toLocaleString('en-IN');

export default function Home() {
  const navigate = useNavigate();
  const { products } = useProducts();

  useEffect(() => {
    document.title = 'Free Fire Store – Premium Fashion & Apparel';
  }, []);

  const hero = products.find((p) => p.badge === 'FEATURED') || products[0];
  const second = products.find((p) => p.cat === 'women') || hero;
  const feature = products.filter((p) => p.featured || p.badge === 'NEW').slice(0, 4);

  const moods: Record<string, string> = {
    women: 'Find your everyday fit.',
    men: 'A little statement. Every day.',
    kids: 'The art of getting dressed.',
  };

  return (
    <>
      <section className="editorial-hero">
        <div className="editorial-copy">
          <span className="eyebrow">THE FREE FIRE EDIT</span>
          <h1>
            Your everyday.
            <br />
            <em>Anything but ordinary.</em>
          </h1>
          <p>
            From an easy morning to an evening out. Discover pieces that feel
            like you, at prices you can feel good about.
          </p>
          <div className="editorial-actions">
            <button className="button" onClick={() => navigate('/collections/all')}>
              Find your next favourite <ArrowUpRight size={18} />
            </button>
            <button className="text-link" onClick={() => document.getElementById('shop-categories')?.scrollIntoView({ behavior: 'smooth' })}>
              Shop by category <ArrowRight size={16} />
            </button>
          </div>
          <span className="editorial-footnote">YOUR STYLE. YOUR OWN WAY.</span>
        </div>
        <div className="editorial-images">
          {hero && (
            <Link className="editorial-main" to={`/product/${hero.id}`}>
              <img src={hero.images?.[0] || '/placeholder.svg'} alt={hero.name} fetchPriority="high" />
              <span>
                The statement edit <ArrowUpRight size={18} />
              </span>
            </Link>
          )}
          <Link className="editorial-inset" to="/collections/women">
            <img src={second.images?.[0] || '/placeholder.svg'} alt="Explore women's collection" />
            <span>
              Better together <ArrowUpRight size={16} />
            </span>
          </Link>
          <span className="editorial-stamp" aria-hidden="true">
            FREE FIRE
            <br />
            <small>PREMIUM FASHION</small>
          </span>
        </div>
      </section>

      <div className="customer-promises">
        <Link to="/policies/shipping">
          <Truck size={20} />
          <span>
            <strong>Delivery, explained</strong>
            <small>Estimated 3–10 days</small>
          </span>
          <ArrowUpRight size={16} />
        </Link>
        <Link to="/policies/refund">
          <ShoppingBag size={20} />
          <span>
            <strong>Know your return window</strong>
            <small>7 days easy returns</small>
          </span>
          <ArrowUpRight size={16} />
        </Link>
        <Link to="/contact">
          <UserRound size={20} />
          <span>
            <strong>A real person to help</strong>
            <small>Email or call anytime</small>
          </span>
          <ArrowUpRight size={16} />
        </Link>
      </div>

      <section className="section category-edit" id="shop-categories">
        <div className="section-heading">
          <div>
            <span className="eyebrow">FIND YOUR KIND OF STYLE</span>
            <h2>Start with what you love.</h2>
          </div>
          <button className="text-link" onClick={() => navigate('/collections/all')}>
            Explore everything <ArrowUpRight size={17} />
          </button>
        </div>
        <div className="category-tiles">
          {['women', 'men', 'kids'].map((cat, index) => {
            const pieces = products.filter((p) => p.cat === cat);
            const piece = pieces[0];
            return (
              <button key={cat} onClick={() => navigate(`/collections/${cat}`)}>
                <div className="category-image">
                  <img
                    src={piece?.images?.[0] || '/placeholder.svg'}
                    alt={cat}
                    loading="lazy"
                  />
                  <b>0{index + 1}</b>
                </div>
                <span>
                  {cat.charAt(0).toUpperCase() + cat.slice(1)}
                  <small>{moods[cat]}</small>
                </span>
                <ArrowUpRight size={20} />
              </button>
            );
          })}
        </div>
      </section>

      <section className="section">
        <div className="section-heading">
          <div>
            <span className="eyebrow">A PIECE FROM EVERY EDIT</span>
            <h2>Meet your next favourites.</h2>
          </div>
          <button className="text-link" onClick={() => navigate('/collections/all')}>
            Shop the collection <ArrowUpRight size={17} />
          </button>
        </div>
        <div className="product-grid">
          {feature.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      <section className="store-introduction section">
        <div>
          <span className="eyebrow">GET TO KNOW FREE FIRE STORE</span>
          <h2>
            Good style starts
            <br />
            with <em>feeling at home.</em>
          </h2>
          <button className="text-link" onClick={() => navigate('/about')}>
            Our story <ArrowUpRight size={17} />
          </button>
        </div>
        <div>
          <p>
            We’re Free Fire Store, operated by KALPANA SINGH in Sultanpur,
            Uttar Pradesh. Questions about a size, your delivery or a return?
            Our contact details and policies are always here.
          </p>
          <a href="mailto:connectwithgarena@gmail.com">
            connectwithgarena@gmail.com <ArrowUpRight size={16} />
          </a>
          <button className="text-link" onClick={() => navigate('/contact')}>
            Meet us & get in touch <ArrowRight size={16} />
          </button>
        </div>
      </section>
    </>
  );
}
