import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { toast } from 'sonner';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      toast.error('Please enter your email and password.');
      return;
    }

    const toastId = toast.loading('Logging you in...');
    try {
      const emailLower = email.trim().toLowerCase();
      const userRef = doc(db, 'users', emailLower);
      const userSnap = await getDoc(userRef);

      if (!userSnap.exists()) {
        toast.dismiss(toastId);
        toast.error('No account found for this email. Please register first.');
        return;
      }

      const userData = userSnap.data();
      if (userData && userData.password === password) {
        login(userData.email || emailLower, userData.name || '', userData.mobile || '');
        toast.dismiss(toastId);
        toast.success(`Welcome back, ${userData.name || 'User'}!`);
        
        const redirectId = localStorage.getItem('redirect_product_id');
        if (redirectId) {
          localStorage.removeItem('redirect_product_id');
          navigate(`/product/${redirectId}`);
        } else {
          navigate('/my-orders');
        }
      } else {
        toast.dismiss(toastId);
        toast.error('Incorrect password. Please check your password or contact support.');
      }
    } catch (error: any) {
      toast.dismiss(toastId);
      toast.error(error.message || 'Error logging in. Please try again.');
    }
  };

  return (
    <div className="auth-wrap">
      <div className="auth-box">
        <h1>WELCOME BACK</h1>
        <p>Sign in to your Free Fire Store account</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="form-group">
            <label className="form-label">EMAIL ADDRESS *</label>
            <input
              type="email"
              className="form-input"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label className="form-label">PASSWORD *</label>
            <input
              type="password"
              className="form-input"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn btn-black btn-full btn-lg">
            LOG IN
          </button>
        </form>
        <div className="auth-link">
          Don't have an account? <Link to="/register">Create one</Link>
        </div>
      </div>
    </div>
  );
}
