import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useProducts } from '../context/ProductContext';
import { useCart } from '../context/CartContext';
import { toast } from 'sonner';
import { Truck, ShoppingBag, UserRound, LockKeyhole, Star, Check, Plus, ArrowRight, Share2 } from 'lucide-react';

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { products } = useProducts();

  const product = products.find(p => p.id === Number(id));

  const availableColors = product?.colors && product.colors.length > 0
    ? product.colors
    : Array.from(new Set(product?.variants?.map(v => v.color).filter(Boolean) as string[] || []));

  const [selectedColor, setSelectedColor] = useState<string>('');
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [qty, setQty] = useState<number>(1);
  const [activeThumb, setActiveThumb] = useState<number>(1);

  useEffect(() => {
    const defaultColor = availableColors[0] || '';
    setSelectedColor(defaultColor);
    setSelectedSize('');
    setQty(1);
    setActiveThumb(1);
    window.scrollTo({ top: 0, behavior: 'smooth' });

    if (product) {
      document.title = `${product.name} – Free Fire Store`;

      const updateMetaTag = (selector: string, attrName: string, attrVal: string, content: string) => {
        let element = document.querySelector(selector);
        if (!element) {
          element = document.createElement('meta');
          element.setAttribute(attrName, attrVal);
          document.head.appendChild(element);
        }
        element.setAttribute('content', content);
      };

      const productImg = displayedImages[0] || product.images?.[0] || 'https://images.unsplash.com/photo-1445205170230-053b83016050?auto=format&fit=crop&w=1200&q=80';
      const descText = product.desc || `${product.name} available at Free Fire Store. Express delivery & Cash on Delivery available across India.`;
      const currentUrl = window.location.href;

      updateMetaTag('meta[property="og:title"]', 'property', 'og:title', `${product.name} – Free Fire Store`);
      updateMetaTag('meta[property="og:description"]', 'property', 'og:description', descText);
      updateMetaTag('meta[property="og:image"]', 'property', 'og:image', productImg);
      updateMetaTag('meta[property="og:url"]', 'property', 'og:url', currentUrl);
      updateMetaTag('meta[property="og:site_name"]', 'property', 'og:site_name', 'Free Fire Store');
      updateMetaTag('meta[property="og:type"]', 'property', 'og:type', 'product');

      updateMetaTag('meta[name="twitter:card"]', 'name', 'twitter:card', 'summary_large_image');
      updateMetaTag('meta[name="twitter:title"]', 'name', 'twitter:title', `${product.name} – Free Fire Store`);
      updateMetaTag('meta[name="twitter:description"]', 'name', 'twitter:description', descText);
      updateMetaTag('meta[name="twitter:image"]', 'name', 'twitter:image', productImg);
    }

    return () => {
      document.title = 'Free Fire Store – Premium Clothing & Fashion';
    };
  }, [id, product]);

  const getDisplayedImages = (): string[] => {
    if (!product) return [];
    if (selectedColor && product.variantImages && product.variantImages[selectedColor] && product.variantImages[selectedColor].length > 0) {
      return product.variantImages[selectedColor];
    }
    const colorVariant = product.variants?.find(v => v.color === selectedColor);
    if (colorVariant?.image) {
      return [colorVariant.image];
    }
    return product.images || [];
  };

  const displayedImages = getDisplayedImages();

  const nextSlide = () => {
    if (displayedImages && displayedImages.length > 0) {
      setActiveThumb(prev => (prev >= displayedImages.length ? 1 : prev + 1));
    }
  };

  const prevSlide = () => {
    if (displayedImages && displayedImages.length > 0) {
      setActiveThumb(prev => (prev <= 1 ? displayedImages.length : prev - 1));
    }
  };

  useEffect(() => {
    if (!displayedImages || displayedImages.length <= 1) return;
    const timer = setInterval(nextSlide, 4000);
    return () => clearInterval(timer);
  }, [displayedImages, activeThumb]);

  const [touchStartX, setTouchStartX] = useState<number | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStartX(e.touches[0].clientX);
  };

  const handleShareProduct = async () => {
    if (!product) return;
    const shareUrl = window.location.href;
    const shareText = `Check out ${product.name} at Free Fire Store – ₹${product.price}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: `${product.name} – Free Fire Store`,
          text: shareText,
          url: shareUrl
        });
      } catch {
        await navigator.clipboard.writeText(shareUrl);
        toast.success('Product link copied to clipboard!');
      }
    } else {
      await navigator.clipboard.writeText(shareUrl);
      toast.success('Product link copied to clipboard!');
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX === null || !product) return;
    const touchEndX = e.changedTouches[0].clientX;
    const diff = touchStartX - touchEndX;

    if (Math.abs(diff) > 50) {
      if (diff > 0) nextSlide();
      else prevSlide();
    }
    setTouchStartX(null);
  };

  if (!product) {
    return (
      <div className="container" style={{ padding: '100px 20px', textAlign: 'center' }}>
        <h2 style={{ fontSize: '1.8rem', marginBottom: '16px' }}>PRODUCT NOT FOUND</h2>
        <p style={{ color: 'var(--gray)', marginBottom: '24px' }}>The product you are looking for does not exist or has been removed.</p>
        <Link to="/collections/all" className="btn btn-black">BACK TO SHOP</Link>
      </div>
    );
  }

  const fmt = (n: number) => '₹' + n.toLocaleString('en-IN');
  const disc = product.orig ? Math.round(((product.orig - product.price) / product.orig) * 100) : 0;

  const handleSizeSelect = (size: string) => {
    setSelectedSize(size);
  };

  const handleQtyChange = (delta: number) => {
    setQty(prev => Math.max(1, prev + delta));
  };

  const handleAddCurrentToCart = () => {
    if (!selectedSize && product.sizes[0] !== 'ONE SIZE' && product.sizes[0] !== 'FREE SIZE') {
      toast.warning('⚠ PLEASE SELECT A SIZE');
      return;
    }
    const size = selectedSize || product.sizes[0];
    const customImage = displayedImages && displayedImages.length > 0 ? displayedImages[0] : undefined;
    addToCart(product, size, qty, selectedColor, customImage);
  };

  const handleBuyNow = () => {
    if (!selectedSize && product.sizes[0] !== 'ONE SIZE' && product.sizes[0] !== 'FREE SIZE') {
      toast.warning('⚠ PLEASE SELECT A SIZE');
      return;
    }
    const size = selectedSize || product.sizes[0];
    const customImage = displayedImages && displayedImages.length > 0 ? displayedImages[0] : undefined;
    navigate('/checkout', { state: { product, size, qty, color: selectedColor, customImage } });
  };

  const getCategoryLabel = (cat: string) => {
    if (cat === 'men') return "Men's Collection";
    if (cat === 'women') return "Women's Collection";
    if (cat === 'kids') return "Kids' Collection";
    return cat.charAt(0).toUpperCase() + cat.slice(1);
  };

  return (
    <section className="section detail">
      <nav className="breadcrumbs">
        <div className="container">
          <div className="breadcrumb-inner">
            <Link to="/">Home</Link>
            <span className="sep">/</span>
            <Link to={`/collections/${product.cat}`}>{getCategoryLabel(product.cat)}</Link>
            <span className="sep">/</span>
            <span className="curr" title={product.name}>{product.name}</span>
          </div>
        </div>
      </nav>

      <div className="container">
        <div className="detail-grid">
          <div>
            <div
              className="main-photo"
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
            >
              {displayedImages && displayedImages.length > 0 ? (
                <>
                  <img
                    src={displayedImages[Math.min(activeThumb - 1, displayedImages.length - 1)]}
                    alt={`${product.name} ${selectedColor}`}
                    fetchPriority="high"
                    onError={(e) => {
                      const target = e.currentTarget;
                      target.onerror = null;
                      target.src = 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=800&auto=format&fit=crop';
                    }}
                  />
                  {displayedImages.length > 1 && (
                    <>
                      <button onClick={(e) => { e.preventDefault(); e.stopPropagation(); prevSlide(); }} className="gallery-nav-btn prev" aria-label="Previous image" type="button">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 18l-6-6 6-6"/></svg>
                      </button>
                      <button onClick={(e) => { e.preventDefault(); e.stopPropagation(); nextSlide(); }} className="gallery-nav-btn next" aria-label="Next image" type="button">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 18l6-6-6-6"/></svg>
                      </button>
                      <div className="gallery-dots">
                        {displayedImages.map((_, idx) => (
                          <span
                            key={idx}
                            className={`gallery-dot ${activeThumb === idx + 1 ? 'active' : ''}`}
                            onClick={(e) => { e.preventDefault(); e.stopPropagation(); setActiveThumb(idx + 1); }}
                          />
                        ))}
                      </div>
                    </>
                  )}
                </>
              ) : (
                <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '80px', background: 'var(--light)' }}>
                  {product.cat === 'men' ? '👕' : product.cat === 'women' ? '👗' : '💻'}
                </div>
              )}
            </div>

            <div className="thumbnails">
              {displayedImages && displayedImages.length > 0 ? (
                displayedImages.map((imgUrl, i) => (
                  <button
                    key={i}
                    className={activeThumb === i + 1 ? 'selected' : ''}
                    onClick={() => setActiveThumb(i + 1)}
                    aria-label={`View photo ${i + 1}`}
                  >
                    <img
                      src={imgUrl}
                      alt={`${product.name} Thumb ${i + 1}`}
                      loading="lazy"
                      onError={(e) => {
                        const target = e.currentTarget;
                        target.onerror = null;
                        target.src = 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=800&auto=format&fit=crop';
                      }}
                    />
                  </button>
                ))
              ) : (
                [1, 2, 3].map(i => (
                  <button
                    key={i}
                    className={activeThumb === i ? 'selected' : ''}
                    onClick={() => setActiveThumb(i)}
                    style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '22px', background: 'var(--light)', width: '100%', aspectRatio: '3/4' }}
                  >
                    {product.cat === 'men' ? '👕' : product.cat === 'women' ? '👗' : '💻'}
                  </button>
                ))
              )}
            </div>
          </div>

          <div className="detail-copy">
            <span className="eyebrow">THE {product.cat.toUpperCase()} EDIT</span>
            <h1>{product.name}</h1>
            <div className="detail-price">
              {fmt(product.price)}
              {product.orig > 0 && <span className="was">{fmt(product.orig)}</span>}
              {disc > 0 && <span className="save">SAVE {disc}%</span>}
            </div>
            <p className="muted">Inclusive of applicable taxes</p>
            <Link to="#reviews-title" className="text-link">
              <Star size={15} /> Read product reviews
            </Link>

            <div className="pdp-service">
              <span>
                <Truck size={17} /> Delivery in approximately 3–10 days
              </span>
              <span>
                <Check size={17} /> 7-day easy returns{" "}
                <Link to="/policies/refund">Details</Link>
              </span>
            </div>

            {availableColors.length > 0 && (
              <>
                <div className="option-label">
                  Colour <strong>{selectedColor || availableColors[0]}</strong>
                </div>
                <div className="options">
                  {availableColors.map(color => (
                    <button
                      key={color}
                      className={selectedColor === color ? 'selected' : ''}
                      onClick={() => {
                        setSelectedColor(color);
                        setActiveThumb(1);
                      }}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </>
            )}

            <div className="option-label">
              Select your size <strong>{selectedSize || 'Choose a fit'}</strong>
            </div>
            <div className="options">
              {product.sizes.map(size => (
                <button
                  key={size}
                  className={selectedSize === size ? 'selected' : ''}
                  onClick={() => handleSizeSelect(size)}
                >
                  {size}
                </button>
              ))}
            </div>

            <div className="qty-row">
              <div className="option-label" style={{ marginBottom: 0 }}>Qty</div>
              <div className="qty-ctrl">
                <button onClick={() => handleQtyChange(-1)} type="button">−</button>
                <span id="pdQty">{qty}</span>
                <button onClick={() => handleQtyChange(1)} type="button">+</button>
              </div>
            </div>

            <div className="pd-actions">
              <button className="btn btn-black" onClick={handleAddCurrentToCart}>
                ADD TO BAG
              </button>
              <button className="btn btn-buy-now" onClick={handleBuyNow}>
                BUY NOW
              </button>
              <button
                className="btn"
                onClick={handleShareProduct}
                title="Share Product"
                style={{ background: 'var(--bg)', color: 'var(--dark)', border: '1px solid var(--border)', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}
              >
                <Share2 size={16} /> SHARE
              </button>
            </div>

            <div className="pd-meta">
              <div className="pd-meta-item"><Truck size={14} /> Free delivery on all orders across India</div>
              <div className="pd-meta-item"><Check size={14} /> Easy 7-day return & exchange policy</div>
              <div className="pd-meta-item"><ShoppingBag size={14} /> Cash on Delivery (COD) available nationwide</div>
              <div className="pd-meta-item"><LockKeyhole size={14} /> In stock — ships in 1–2 business days</div>
            </div>

            <details open style={{ marginTop: '24px', borderTop: '1px solid var(--border)', paddingTop: '16px' }}>
              <summary style={{ fontFamily: 'var(--font-h)', fontWeight: 700, fontSize: '13px', letterSpacing: '1px', textTransform: 'uppercase', cursor: 'pointer', listStyle: 'none', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Plus size={16} /> Product Details
              </summary>
              <p style={{ marginTop: '12px', fontSize: '14px', color: 'var(--gray)', lineHeight: '1.7', whiteSpace: 'pre-line' }}>{product.desc}</p>
            </details>
          </div>
        </div>

        <div className="related-products-section" style={{ marginTop: '64px', borderTop: '1px solid var(--border)', paddingTop: '48px', marginBottom: '48px' }}>
          <div className="section-heading" style={{ textAlign: 'center', marginBottom: '32px' }}>
            <h2 style={{ fontFamily: 'var(--font-h)', fontSize: '20px', fontWeight: 800, letterSpacing: '1.5px', textTransform: 'uppercase' }}>YOU MAY ALSO LIKE</h2>
            <div style={{ width: '40px', height: '2px', background: 'var(--accent)', margin: '8px auto 0' }}></div>
          </div>
          <div className="product-grid" id="related-products-grid">
            {products.filter(p => p.cat === product.cat && p.id !== product.id).slice(0, 4).map(p => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
