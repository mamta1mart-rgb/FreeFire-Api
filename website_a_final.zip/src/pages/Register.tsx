import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { toast } from 'sonner';

export default function Register() {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !email.trim() || !mobile.trim() || !password.trim()) {
      toast.error('Please enter all required details.');
      return;
    }

    const toastId = toast.loading('Creating your account...');
    try {
      const emailLower = email.trim().toLowerCase();
      const userRef = doc(db, 'users', emailLower);
      const userSnap = await getDoc(userRef);

      if (userSnap.exists()) {
        toast.dismiss(toastId);
        toast.error('User already registered.');
        return;
      }

      await setDoc(userRef, {
        name: fullName.trim(),
        email: emailLower,
        mobile: mobile.trim(),
        pincode: '',
        password: password,
        createdAt: new Date().toISOString()
      });

      login(emailLower, fullName.trim(), mobile.trim());
      toast.dismiss(toastId);
      toast.success('Account created successfully! Welcome to Free Fire Store.');
      
      const redirectId = localStorage.getItem('redirect_product_id');
      if (redirectId) {
        localStorage.removeItem('redirect_product_id');
        navigate(`/product/${redirectId}`);
      } else {
        navigate('/my-orders');
      }
    } catch (error: any) {
      toast.dismiss(toastId);
      toast.error(error.message || 'Error registering account. Please try again.');
    }
  };

  return (
    <div className="auth-wrap">
      <div className="auth-box">
        <h1>CREATE ACCOUNT</h1>
        <p>Join Free Fire Store for premium fashion and exclusive drops</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="form-group">
            <label className="form-label">FULL NAME *</label>
            <input
              type="text"
              className="form-input"
              placeholder="Your full name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label className="form-label">EMAIL ADDRESS *</label>
            <input
              type="email"
              className="form-input"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label className="form-label">MOBILE NUMBER *</label>
            <input
              type="tel"
              className="form-input"
              placeholder="+91 9876543210"
              value={mobile}
              onChange={(e) => setMobile(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label className="form-label">PASSWORD *</label>
            <input
              type="password"
              className="form-input"
              placeholder="Create a password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn btn-black btn-full btn-lg">
            CREATE ACCOUNT
          </button>
        </form>
        <div className="auth-link">
          Already have an account? <Link to="/login">Sign in</Link>
        </div>
      </div>
    </div>
  );
}
