import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useProducts } from '../context/ProductContext';
import { Search as SearchIcon } from 'lucide-react';
import ProductCard from '../components/ProductCard';

export default function Search() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { products } = useProducts();
  const initialQuery = searchParams.get('q') || '';

  const [query, setQuery] = useState(initialQuery);

  useEffect(() => {
    setQuery(searchParams.get('q') || '');
  }, [searchParams]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      setSearchParams({ q: query.trim() });
    } else {
      setSearchParams({});
    }
  };

  const filteredProducts = products.filter(p => {
    if (!query.trim()) return false;
    const q = query.toLowerCase();
    return p.name.toLowerCase().includes(q) || p.cat.toLowerCase().includes(q);
  });

  return (
    <div id="search-page-root">
      <div className="search-hero">
        <div className="container">
          <h1>Find your next favourite</h1>
          <form onSubmit={handleSearchSubmit} className="search-bar-lg">
            <SearchIcon size={20} style={{ color: 'var(--gray)', flexShrink: 0 }} />
            <input
              type="text"
              placeholder="Try a top, shirt or kurti…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              id="searchMainInput"
              autoFocus
            />
            <button type="submit">SEARCH</button>
          </form>
        </div>
      </div>

      <div className="container" style={{ padding: '40px 20px 60px' }}>
        {query.trim() === '' ? (
          <div style={{ textAlign: 'center', padding: '60px 20px' }}>
            <SearchIcon size={48} style={{ marginBottom: '16px', color: 'var(--light)' }} />
            <h2 style={{ fontSize: '1.2rem', textTransform: 'uppercase', letterSpacing: '2px', marginBottom: '8px' }}>START TYPING TO SEARCH</h2>
            <p style={{ color: 'var(--gray)' }}>Discover premium fashion and apparel across our collections.</p>
          </div>
        ) : filteredProducts.length > 0 ? (
          <div>
            <div style={{ marginBottom: '20px', fontFamily: 'var(--font-h)', fontSize: '12px', fontWeight: 700, letterSpacing: '1.5px', textTransform: 'uppercase', color: 'var(--gray)' }}>
              {filteredProducts.length} RESULTS FOR "{query.toUpperCase()}"
            </div>
            <div className="product-grid">
              {filteredProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        ) : (
          <div style={{ textAlign: 'center', padding: '60px 20px' }}>
            <SearchIcon size={48} style={{ marginBottom: '16px', color: 'var(--light)' }} />
            <h2 style={{ fontSize: '1.2rem', textTransform: 'uppercase', letterSpacing: '2px', marginBottom: '8px' }}>NO RESULTS FOUND</h2>
            <p style={{ color: 'var(--gray)' }}>Try different keywords or browse our collections.</p>
            <button className="btn btn-black" style={{ marginTop: '20px' }} onClick={() => navigate('/collections/all')}>
              BROWSE ALL PRODUCTS
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
